package com.TC;

import org.testng.annotations.Test;

public class FirstTestScenario {


    @Test
    public void testLogin()
    {
        System.out.println("login successful");
    }

    public void testlogout()
    {
        System.out.println("logout successful");
    }
}
