package TestCases;

import POM.GooglePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.openqa.selenium.WebElement;
import org.testng.annotations.*;

import java.time.Duration;

public class RegressionTC1 {

    static WebDriver driver;
    GooglePage googlePage;

    @BeforeMethod
    public void start(){

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

        driver.get("https://www.google.com/");

        googlePage = new GooglePage(driver);

    }

    @Test
    public void TC1()
    {

        Assert.assertEquals(googlePage.getPageTitle(), "Google"); //TC1
    }

    @Test
    public void TC2()
    {
        Assert.assertEquals(googlePage.getPageTitle(), "Java");
    }

    @Test
    public void TC3()
    {
        Assert.assertEquals(googlePage.getaboutLinkText(), "Abouttt"); //TC3
    }

    @Test
    public void TC4()
    {

        Assert.assertTrue(googlePage.checkGoogleSearchButton(),"Search Button is not enabled"); //TC4
    }

    @AfterMethod
    public void stop(){

        driver.quit();
    }
}
